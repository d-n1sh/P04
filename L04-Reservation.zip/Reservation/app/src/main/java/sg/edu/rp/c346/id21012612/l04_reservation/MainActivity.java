package sg.edu.rp.c346.id21012612.l04_reservation;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

TextView displayName;
EditText editName;
TextView displayNo;
EditText editNo;
TextView displaySize;
EditText editSize;
RadioGroup rgArea;
TextView displayDate;
DatePicker dp;
TextView displayTime;
TimePicker tp;
Button btnSubmit;
Button btnReset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        displayName = findViewById(R.id.viewName);
        editName = findViewById(R.id.editName);
        displayNo = findViewById(R.id.viewNumber);
        editNo = findViewById(R.id.editNumber);
        displaySize = findViewById(R.id.viewSize);
        editSize = findViewById(R.id.editSize);
        rgArea = findViewById(R.id.RadioGroupArea);
        displayDate = findViewById(R.id.viewDate);
        displayTime = findViewById(R.id.viewTime);
        dp = findViewById(R.id.datePicker);
        tp = findViewById(R.id.timePicker);
        btnSubmit = findViewById(R.id.buttonSubmit);
        btnReset = findViewById(R.id.buttonReset);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
            if (editName != null && editNo.length() != 0 && editSize.length() != 0){
                if (rgArea.getCheckedRadioButtonId() == R.id.radioButtonSmoke){
                    String area = "Smoking area";
                    String message = "Reservation for " + editName.getText() + " with Contact Number "
                            + editNo.getText().toString() + " and Group Size of " + editSize.getText().toString()
                            + " in " + area + " on " + dp.getDayOfMonth()
                            + "/" + (dp.getMonth()+1) + "/" + dp.getYear() + ", "
                            + tp.getCurrentHour() + ":" + tp.getMinute();
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();

                }
                else{
                    String area = "Non-smoking area";
                    String message = "Reservation for " + editName.getText() + " with Contact Number "
                            + editNo.getText().toString() + " and Group Size of " + editSize.getText().toString()
                            + " in " + area + " on " + dp.getDayOfMonth()
                            + "/" + (dp.getMonth()+1) + "/" + dp.getYear() + ", "
                            + tp.getCurrentHour() + ":" + tp.getMinute();
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();

                }

            }
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                editName.setText("");
                editNo.setText("");
                editSize.setText("");
                tp.setHour(19);
                tp.setMinute(30);
                dp.updateDate(2020,5,1);
            }
        });

    }
}